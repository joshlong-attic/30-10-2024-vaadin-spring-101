package com.example.graalvm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraalvmApplicationTests {

	@Test
	void contextLoads() {
	}

}
